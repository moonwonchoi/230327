price = 20000
ea = 10

print(price * ea)
total = price * ea
print(total)

s = "hello"
t = "python"

# f string
text1 = f"{s} {t}"
text2 = f"{s}! {t}"
# format
text3 = "{} {}".format(s, t)
# 서식문자열
text4 = "%s %s" % (s, t)
# 연산자
text5 = s + " " + t
# print()
print(s, t)
print(s, "! ", t, sep ="")

a = "100"
b = "200"

a = int(a)
b = int(b)
print(a+b)

chairprice = 3000000
month = 36
print(int(chairprice/month))






