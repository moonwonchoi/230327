class testself: # testself 클래스 및 정의
    def __init__(self, x):
        self.a = x
        
    def calltest(self):
        print(self.a)

    
obj_1 = testself(11) # testself 인스턴스 생성 
obj_2 = testself(22)

obj_1.calltest()  # -> testself -> calltest() -> calltest(obj_1)
obj_2.calltest()
