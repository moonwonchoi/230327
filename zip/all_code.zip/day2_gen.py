import sys

a = [n for n in range(1000000)]
b = range(1000000)

print(type(a))
print(type(b))

print(sys.getsizeof(a))
print(sys.getsizeof(b))

