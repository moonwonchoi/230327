class HUMAN:
    def walk:
        pass


class WORKER:
    def __init__(self, humancls):
        self.humanobj = humancls
        

    def walk():
        self.humanobj.walk()
        print("와우")

        

