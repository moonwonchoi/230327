def extractData(data, start): ## string에서 조건을 만족하는 구역의 문자열을 추출 함수
    global searchidx
    
    token_start_index = data.index("s", start)
    token_end_index = data.index("e",token_start_index)
    print(token_start_index, token_end_index)
    print(data[token_start_index+1:token_end_index])

    next_chr_s_index = data.index("s", token_start_index + 1)
    if next_chr_s_index < token_end_index:
        print("오류 데이터 입니다")
        searchidx = token_start_index + 1
    else:
        searchidx = token_end_index
        return data[token_start_index+1:token_end_index]
    
def storeData(values): ## 3개값 추출 (온도, 속도, 중량)
    if values != None:
        datas = values.split(",")  # 88,13,15  -> ["88", "13", "15"]
        temperture.append(int(datas[0]))
        speed.append(int(datas[1]))
        weight.append(int(datas[2]))

        print(temperture, speed, weight)
    
def printAvg(): ## 저장된 데이터를 평균계산해서 화면에 출력
    tempavg = sum(temperture) / len(temperture)
    speedavg = sum(speed) / len(speed)
    weightavg = sum(weight) / len(weight)

    print("평균값:", "온도:",round(tempavg, 2), "속도:",speedavg , "중량:",weightavg)

#----- 파일을 읽어서 파일에 내용을 분석
#----- 웹 소스코드
#----- 소켓


data = "s88,39,33es12,33,45es33,32s13,77,45es33,55,66e"
print("읽은파일데이터:", data)



temperture = []
speed = []
weight = []

searchidx = 0   #내가 마지막 조사한 위치

token = extractData(data, searchidx)  # s ~~ e -> 온도, 속도, 중량
print(token)
storeData(token)
token = extractData(data, searchidx)  # s ~~ e -> 온도, 속도, 중량
print(token)
storeData(token)
printAvg()
token = extractData(data, searchidx)  # s ~~ e -> 온도, 속도, 중량
print(token)
storeData(token)
printAvg()
token = extractData(data, searchidx)  # s ~~ e -> 온도, 속도, 중량
print(token)
storeData(token)
printAvg()





##print(token)
##storeData(token)
##printAvg()
##token = extractData(data, searchidx)
##print(token)
##storeData(token)
##printAvg()
##token = extractData(data, searchidx)
##print(token)
##storeData(token)
##printAvg()
##token = extractData(data, searchidx)
##print(token)
##storeData(token)
##printAvg()
##    
##
