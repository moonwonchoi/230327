import requests
from bs4 import BeautifulSoup

url = "https://m.stock.naver.com/marketindex/home/major/exchange/bond"
response = requests.get(url)

if response.status_code == 200:
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    #title = soup.select_one("#__next > div.MainList_article__sGjxm > ul > li:nth-child(1) > a > span.MainListItem_price__dP8R6")
    title = soup.select_one("span.MainListItem_price__dP8R6")
    
    print(title)
    print(title.getText())

else : 
    print(response.status_code)


