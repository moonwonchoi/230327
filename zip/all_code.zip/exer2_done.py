datas = "s88,39,33es12,33,45es33,32s13,77,45es33,55,66e"

##search_s = 0
##search_e = 0
##found_s_pos = datas.index("s", search_s)
##found_e_pos = datas.index("e", search_e)
##
##data = datas[found_s_pos+1:found_e_pos]
##values = data.split(",")
##print(data)
##print(values)
##
##search_s = found_s_pos + 1
##search_e = found_e_pos + 1
##
##found_s_pos = datas.index("s", search_s)
##found_e_pos = datas.index("e", search_e)
##
##data = datas[found_s_pos+1:found_e_pos]
##values = data.split(",")
##print(data)
##print(values)
##
##search_s = found_s_pos + 1
##search_e = found_e_pos + 1
##
##found_s_pos = datas.index("s", search_s)
##found_s_second_pos = datas.index("s", found_s_pos + 1)
##found_e_pos = datas.index("e", search_e)
##
##if found_s_second_pos < found_e_pos:
##    print("오류")
##    search_s = found_s_pos + 1
##else:
##    data = datas[found_s_pos+1:found_e_pos]
##    values = data.split(",")
##    print(data)
##    print(values)
##
##
##found_s_pos = datas.index("s", search_s)
##found_s_second_pos = datas.index("s", found_s_pos + 1)
##found_e_pos = datas.index("e", search_e)
##
##if found_s_second_pos < found_e_pos:
##    print("오류")
##    search_s = found_s_pos + 1
##else:
##    data = datas[found_s_pos+1:found_e_pos]
##    values = data.split(",")
##    print(data)
##    print(values)

search_s = 0
search_e = 0
found_s_pos = 0
found_s_second_pos = 0
found_e_pos = 0

temp = 0
spd = 0
weg = 0
while True:    
    found_s_pos = datas.index("s", search_s)
    #found_s_second_pos = datas.find("s", found_s_pos + 1)
    try:
        found_s_second_pos = datas.index("s", found_s_pos + 1)
    except:
        found_s_second_pos = 9999
        pass
        
    found_e_pos = datas.index("e", search_e)

    if found_s_second_pos < found_e_pos:
        print("오류")
        search_s = found_s_pos + 1
    else:
        data = datas[found_s_pos+1:found_e_pos]
        values = data.split(",")
        print(data)
        print(values)
        temp = temp + int(values[0])
        spd = spd + int(values[1])
        weg = weg + int(values[2])
        search_s = found_s_pos + 1
        search_e = found_e_pos + 1

    if found_e_pos >= len(datas) - 1:
        print("자료 끝")
        break


print(temp/4, spd/4, weg/4)

