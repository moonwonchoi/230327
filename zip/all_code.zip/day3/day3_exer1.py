
####
a=12
b=6
c=18

##if a>b and a>c:
##    print("최대값:{}".format(a))
##elif b>a and b>c:
##    print("최대값:{}".format(b))
##elif c>b and c>a:
##    print("최대값:{}".format(c))



list_var = [ a, b, c]

max_var=list_var[0] # 임시변수
for i in range(1,3): # 0, 1, 2 [인덱스]
    if max_var <list_var[i]:
        max_var=list_var[i]
print("최대값:", end = "")
print(max_var)


####
####

for x in range(2,10):
    # 단마다(2단~9단)
    print(f"{x}단 :", end = " ") 
    for y in range(1,10):
        # 9번씩(1~9), #단마다(2단~9단)
        print(f"{x}*{y}={x*y}", end = "\t")
    print("\n", end = "\n");
