def ShowMenu():   
    print("[자판기 판매 메뉴]")
    for i in range(0, len(menu)):
        print("#", i+1, ".", menu[i], "\t가격 : ", price[i])
    print()
 
def BuyItem(num):    
    if money < price[num]:
        print("잔액이 부족합니다. 잔액 : %d" %money) 
        return money
    else:
        print(menu[num], " 구입완료")
        if menu[num] in selllist:
            selllist[menu[num]] = selllist[menu[num]] + 1
        else:
            selllist[menu[num]] = 1
            
        balance = money - price[num]
        print("잔액 : ", balance)
        return balance
 
def ShowSellList():
    print("판매량", selllist)
    
def CheckPassword():
    if input("비밀번호를 입력하세요 : ") == "1234":
        return True
    print("비밀번호 오류")
    return False
 
menu = ("콜라", "사이다", "생수", "커피")
price = (1200, 1000, 700, 1500)
money = 0
money = int( input("돈을 투입하세요 : ") )
selllist = {}

while True:
    ShowMenu()
    sel = int(input("메뉴 번호를 선택하세요 (종료 : 0) : "))
    if sel == 0:
       break;
    elif(sel>=1 and sel <= len(menu)):
       money = BuyItem(sel-1)
    elif(sel == 99):
       if CheckPassword():
           ShowSellList()       
    else:
       print("잘못된 메뉴 번호입니다")

print("자판기 종료, 잔액 %d 반환"%money)
