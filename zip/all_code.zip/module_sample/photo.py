#module 코드

def photo():
    print("take a photo")

if __name__ == "__main__":
    print(__name__)
    photo()
