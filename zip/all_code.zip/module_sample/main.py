import photo as abc
import work_photo as myphoto
from work_photo import *

abc.photo()
myphoto.photo()

photo()


