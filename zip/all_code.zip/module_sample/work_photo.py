#module 코드

def photo():
    print("take a photo workphoto")

if __name__ == "__main__":
    print(__name__)
    photo()
